--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.16 (Debian 11.16-0+deb10u1)
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE db_1;
--
-- Name: db_1; Type: DATABASE; Schema: -; Owner: dev_pre_prod
--

CREATE DATABASE db_1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE db_1 OWNER TO dev_pre_prod;

\connect db_1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: Users_typeuser_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public."Users_typeuser_enum" AS ENUM (
    '1976729',
    '236359',
    '236429359',
    '42659985',
    '963734',
    '548965156',
    '1548965156',
    '2548965156',
    '2363594520',
    '48653128185'
);


ALTER TYPE public."Users_typeuser_enum" OWNER TO dev_pre_prod;

--
-- Name: agence_type_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.agence_type_enum AS ENUM (
    'HUB',
    'BUREAU',
    'CENTRE RETOUR',
    'CAISSE-REGIONAL',
    'CAISSE-CENTRAL'
);


ALTER TYPE public.agence_type_enum OWNER TO dev_pre_prod;

--
-- Name: client_delaipaiement_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.client_delaipaiement_enum AS ENUM (
    'A l''envoi',
    'A la réception de la facture',
    '15 jours',
    '30 jours',
    '45 jours'
);


ALTER TYPE public.client_delaipaiement_enum OWNER TO dev_pre_prod;

--
-- Name: client_jourpayement_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.client_jourpayement_enum AS ENUM (
    'Dimanche',
    'Lundi',
    'Mardi',
    'Mercredi',
    'Jeudi',
    'Vendredi',
    'Samedi'
);


ALTER TYPE public.client_jourpayement_enum OWNER TO dev_pre_prod;

--
-- Name: commune_journeelivraison_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.commune_journeelivraison_enum AS ENUM (
    'Dimanche',
    'Lundi',
    'Mardi',
    'Mercredi',
    'Jeudi',
    'Vendredi',
    'Samedi'
);


ALTER TYPE public.commune_journeelivraison_enum OWNER TO dev_pre_prod;

--
-- Name: sac_typesac_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.sac_typesac_enum AS ENUM (
    'TRAJET VERS WILAYA',
    'TRANSFERT DU TRAJET',
    'VERS AGENCE',
    'TRANSFERT RETOUR',
    'VERS VENDEUR',
    'RETOUR VERS WILAYA',
    'RETOUR VERS AGENCE',
    'ACCUSÉ DE RÉCÉPTION RETOUR CLIENT '
);


ALTER TYPE public.sac_typesac_enum OWNER TO dev_pre_prod;

--
-- Name: shipment_laststatus_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.shipment_laststatus_enum AS ENUM (
    'EN PREPARATION',
    'EN ATTENTE DE LIVRAISON',
    'PRÉS A EXPIDIÉ',
    'RAMASSÉ',
    'EXPIDIÉ',
    'VERS WILAYA',
    'VERS AGENCE',
    'REÇUE AGENCE',
    'TRANSFERT',
    'REÇUE WILAYA',
    'CENTRE',
    'RETOURNÉ EN AGENCE',
    'RETOURNE AU CENTRE',
    'CENTRE RETOUR',
    'RETOUR VERS WILAYA',
    'TRANSITÉ',
    'RETOUR VERS AGENCE',
    'RETOUR REÇU WILAYA',
    'RETOUR REÇU AGENCE',
    'A RETIRÉ',
    'RETIRÉ',
    'RETOUR PAYÉ',
    'AFFECTER AU COURSIER',
    'SORTI EN LIVRASON',
    'EN ALERTE',
    'TENTATIVE ECHOUÉE',
    'EN ATTENTE DU CLIENT',
    'ÉCHEC LIVRAISON',
    'LIVRÉ',
    'EN ATTENTE DE CHANGEMENT',
    'ECHANGÉ',
    'PAS PRÉS',
    'PRÉS RÉCOLTÉ',
    'RÉCOLTÉ',
    'PRÉT A PAYER',
    'PAYER',
    'FACTURÉ'
);


ALTER TYPE public.shipment_laststatus_enum OWNER TO dev_pre_prod;

--
-- Name: status_libelle_enum; Type: TYPE; Schema: public; Owner: dev_pre_prod
--

CREATE TYPE public.status_libelle_enum AS ENUM (
    'EN PREPARATION',
    'EN ATTENTE DE LIVRAISON',
    'PRÉS A EXPIDIÉ',
    'RAMASSÉ',
    'EXPIDIÉ',
    'VERS WILAYA',
    'VERS AGENCE',
    'REÇUE AGENCE',
    'TRANSFERT',
    'REÇUE WILAYA',
    'CENTRE',
    'RETOURNÉ EN AGENCE',
    'RETOURNE AU CENTRE',
    'CENTRE RETOUR',
    'RETOUR VERS WILAYA',
    'TRANSITÉ',
    'RETOUR VERS AGENCE',
    'RETOUR REÇU WILAYA',
    'RETOUR REÇU AGENCE',
    'A RETIRÉ',
    'RETIRÉ',
    'RETOUR PAYÉ',
    'AFFECTER AU COURSIER',
    'SORTI EN LIVRASON',
    'EN ALERTE',
    'TENTATIVE ECHOUÉE',
    'EN ATTENTE DU CLIENT',
    'ÉCHEC LIVRAISON',
    'LIVRÉ',
    'EN ATTENTE DE CHANGEMENT',
    'ECHANGÉ',
    'PAS PRÉS',
    'PRÉS RÉCOLTÉ',
    'RÉCOLTÉ',
    'PRÉT A PAYER',
    'PAYER',
    'FACTURÉ'
);


ALTER TYPE public.status_libelle_enum OWNER TO dev_pre_prod;

SET default_tablespace = '';

--
-- Name: Facture; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public."Facture" (
    id integer NOT NULL,
    "numFacture" character varying,
    "typeFacture" character varying,
    "datePaiement" timestamp without time zone,
    "modePaiement" character varying,
    "numCheque" character varying,
    payer boolean DEFAULT false NOT NULL,
    espece boolean,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone,
    "montantTotal" double precision,
    "montantTva" double precision,
    "montantTtc" double precision,
    "montantTimbre" double precision,
    "montantHoreTaxe" double precision,
    "nbrColis" integer,
    "createdById" integer,
    "createdOnId" integer,
    "clientId" integer
);


ALTER TABLE public."Facture" OWNER TO dev_pre_prod;

--
-- Name: Facture_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public."Facture_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Facture_id_seq" OWNER TO dev_pre_prod;

--
-- Name: Facture_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public."Facture_id_seq" OWNED BY public."Facture".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    password character varying(255) NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deleatedAt" timestamp without time zone,
    "typeUser" public."Users_typeuser_enum" NOT NULL,
    "lastIP" character varying,
    email character varying(50) NOT NULL
);


ALTER TABLE public."Users" OWNER TO dev_pre_prod;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public."Users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO dev_pre_prod;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: agence; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.agence (
    id integer NOT NULL,
    nom character varying NOT NULL,
    code character varying,
    adresse character varying NOT NULL,
    nrc character varying,
    nif character varying,
    nis character varying,
    "nAI" character varying,
    latitude integer,
    longitude integer,
    type public.agence_type_enum,
    "communeZoneOne" integer[],
    "prixRamassageZoneOne" integer,
    "prixRamassageZoneTwo" integer,
    "prixLivraisonZoneOne" integer,
    "prixLivraisonZoneTwo" integer,
    "communeId" integer
);


ALTER TABLE public.agence OWNER TO dev_pre_prod;

--
-- Name: agence_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.agence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agence_id_seq OWNER TO dev_pre_prod;

--
-- Name: agence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.agence_id_seq OWNED BY public.agence.id;


--
-- Name: banque; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.banque (
    id integer NOT NULL,
    nom character varying NOT NULL
);


ALTER TABLE public.banque OWNER TO dev_pre_prod;

--
-- Name: banque_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.banque_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.banque_id_seq OWNER TO dev_pre_prod;

--
-- Name: banque_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.banque_id_seq OWNED BY public.banque.id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.client (
    id integer NOT NULL,
    "numClient" character varying NOT NULL,
    "raisonSociale" character varying NOT NULL,
    "nomCommercial" character varying NOT NULL,
    adresse character varying NOT NULL,
    telephone character varying NOT NULL,
    "nomGerant" character varying NOT NULL,
    "prenomGerant" character varying NOT NULL,
    nrc character varying NOT NULL,
    nif character varying NOT NULL,
    nis character varying NOT NULL,
    "nbEnvoiMin" integer NOT NULL,
    "nbEnvoiMax" integer NOT NULL,
    "nbTentative" integer NOT NULL,
    "poidsBase" integer NOT NULL,
    "tauxCOD" double precision,
    "c_o_d_ApartirDe" double precision,
    "moyenPayement" character varying,
    "jourPayement" public.client_jourpayement_enum[],
    "delaiPaiement" public.client_delaipaiement_enum,
    "tarifRetour" integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    latitude integer,
    longitude integer,
    "communeResidenceId" integer,
    "communeDepartId" integer,
    "userId" integer,
    "agenceRetourId" integer,
    "caisseAgenceId" integer
);


ALTER TABLE public.client OWNER TO dev_pre_prod;

--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_id_seq OWNER TO dev_pre_prod;

--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;


--
-- Name: clients_tarif; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.clients_tarif (
    "clientId" integer NOT NULL,
    "codeTarifId" integer NOT NULL
);


ALTER TABLE public.clients_tarif OWNER TO dev_pre_prod;

--
-- Name: code_tarif; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.code_tarif (
    id integer NOT NULL,
    nom character varying NOT NULL,
    "isStandard" boolean NOT NULL,
    "serviceId" integer
);


ALTER TABLE public.code_tarif OWNER TO dev_pre_prod;

--
-- Name: code_tarif_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.code_tarif_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.code_tarif_id_seq OWNER TO dev_pre_prod;

--
-- Name: code_tarif_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.code_tarif_id_seq OWNED BY public.code_tarif.id;


--
-- Name: code_tarifs_zone; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.code_tarifs_zone (
    id integer NOT NULL,
    "codeTarifId" integer NOT NULL,
    "zoneId" integer NOT NULL,
    "poidsId" integer NOT NULL,
    "tarifStopDesk" double precision,
    delay integer,
    "tarifDomicile" double precision NOT NULL,
    "tarifPoidsParKg" double precision
);


ALTER TABLE public.code_tarifs_zone OWNER TO dev_pre_prod;

--
-- Name: code_tarifs_zone_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.code_tarifs_zone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.code_tarifs_zone_id_seq OWNER TO dev_pre_prod;

--
-- Name: code_tarifs_zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.code_tarifs_zone_id_seq OWNED BY public.code_tarifs_zone.id;


--
-- Name: commune; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.commune (
    id integer NOT NULL,
    "codePostal" character varying NOT NULL,
    "nomLatin" character varying NOT NULL,
    "nomArabe" character varying NOT NULL,
    "livraisonDomicile" boolean DEFAULT false,
    "livraisonStopDesck" boolean,
    livrable boolean DEFAULT false,
    "journeeLivraison" public.commune_journeelivraison_enum[],
    stockage boolean,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deleatedAt" timestamp without time zone,
    "wilayaId" integer
);


ALTER TABLE public.commune OWNER TO dev_pre_prod;

--
-- Name: commune_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.commune_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commune_id_seq OWNER TO dev_pre_prod;

--
-- Name: commune_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.commune_id_seq OWNED BY public.commune.id;


--
-- Name: coursier; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.coursier (
    id integer NOT NULL,
    nom character varying NOT NULL,
    prenom character varying NOT NULL,
    "dateNaissance" timestamp without time zone,
    "lieuNaissance" character varying,
    adresse character varying,
    "numTelephone" character varying NOT NULL,
    "dateRecrutement" timestamp without time zone,
    "typeContrat" character varying,
    "montantRamassage" integer NOT NULL,
    "montantLivraison" integer NOT NULL,
    "MarqueVehicule" character varying,
    "immatriculationVehicule" character varying,
    "agenceId" integer,
    "userId" integer
);


ALTER TABLE public.coursier OWNER TO dev_pre_prod;

--
-- Name: coursier_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.coursier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coursier_id_seq OWNER TO dev_pre_prod;

--
-- Name: coursier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.coursier_id_seq OWNED BY public.coursier.id;


--
-- Name: departement; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.departement (
    id integer NOT NULL,
    nom character varying NOT NULL
);


ALTER TABLE public.departement OWNER TO dev_pre_prod;

--
-- Name: departement_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.departement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departement_id_seq OWNER TO dev_pre_prod;

--
-- Name: departement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.departement_id_seq OWNED BY public.departement.id;


--
-- Name: employe; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.employe (
    id integer NOT NULL,
    "codeEmploye" character varying NOT NULL,
    nom character varying NOT NULL,
    prenom character varying NOT NULL,
    "dateNaissance" timestamp without time zone,
    "lieuNaissance" character varying,
    adresse character varying,
    "numTelephone" character varying NOT NULL,
    nss character varying,
    "numCompteBancaire" character varying,
    genre character varying,
    "groupeSanguin" character varying,
    "dateRecrutement" timestamp without time zone,
    "typeContrat" character varying,
    "userId" integer,
    "fonctionId" integer,
    "banqueId" integer,
    "agenceId" integer
);


ALTER TABLE public.employe OWNER TO dev_pre_prod;

--
-- Name: employe_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.employe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employe_id_seq OWNER TO dev_pre_prod;

--
-- Name: employe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.employe_id_seq OWNED BY public.employe.id;


--
-- Name: expiditeur_public; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.expiditeur_public (
    id integer NOT NULL,
    "adresseExp" character varying,
    "raisonSocialeExp" character varying,
    "nomExp" character varying,
    "prenomExp" character varying,
    "telephoneExp" character varying,
    "numIdentite" character varying
);


ALTER TABLE public.expiditeur_public OWNER TO dev_pre_prod;

--
-- Name: expiditeur_public_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.expiditeur_public_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.expiditeur_public_id_seq OWNER TO dev_pre_prod;

--
-- Name: expiditeur_public_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.expiditeur_public_id_seq OWNED BY public.expiditeur_public.id;


--
-- Name: fonction; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.fonction (
    id integer NOT NULL,
    nom character varying NOT NULL,
    "dureeEssai" character varying,
    "departementId" integer
);


ALTER TABLE public.fonction OWNER TO dev_pre_prod;

--
-- Name: fonction_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.fonction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fonction_id_seq OWNER TO dev_pre_prod;

--
-- Name: fonction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.fonction_id_seq OWNED BY public.fonction.id;


--
-- Name: pmt; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.pmt (
    id integer NOT NULL,
    tracking character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone,
    "validatedAt" timestamp without time zone,
    "confirmedAt" timestamp without time zone,
    "tauxC_O_D" double precision,
    "tarifRetour" double precision,
    tarifs character varying,
    "montantRamasser" double precision,
    "FraisD_envois" double precision,
    "montantC_O_D" double precision,
    "FraisRetour" double precision,
    "netClient" double precision,
    "nbShipmentLivrer" integer,
    "nbShipmentRetour" integer,
    "createdById" integer,
    "createdOnId" integer,
    "validatedById" integer,
    "validatedOnId" integer,
    "confirmedById" integer,
    "wilayaDeparPmtId" integer,
    "clientId" integer
);


ALTER TABLE public.pmt OWNER TO dev_pre_prod;

--
-- Name: pmt_coursier; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.pmt_coursier (
    id integer NOT NULL,
    tracking character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deletedAt" timestamp without time zone,
    "montantTotal" integer,
    "nbrColis" integer,
    "createdById" integer,
    "createdOnId" integer,
    "coursierId" integer
);


ALTER TABLE public.pmt_coursier OWNER TO dev_pre_prod;

--
-- Name: pmt_coursier_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.pmt_coursier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pmt_coursier_id_seq OWNER TO dev_pre_prod;

--
-- Name: pmt_coursier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.pmt_coursier_id_seq OWNED BY public.pmt_coursier.id;


--
-- Name: pmt_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.pmt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pmt_id_seq OWNER TO dev_pre_prod;

--
-- Name: pmt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.pmt_id_seq OWNED BY public.pmt.id;


--
-- Name: poid; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.poid (
    id integer NOT NULL,
    min double precision NOT NULL,
    max double precision NOT NULL
);


ALTER TABLE public.poid OWNER TO dev_pre_prod;

--
-- Name: poid_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.poid_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.poid_id_seq OWNER TO dev_pre_prod;

--
-- Name: poid_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.poid_id_seq OWNED BY public.poid.id;


--
-- Name: recolte; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.recolte (
    id integer NOT NULL,
    tracking character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "receivedAt" timestamp without time zone,
    "typeRtc" character varying,
    montant double precision,
    "createdById" integer,
    "createdOnId" integer,
    "receivedById" integer,
    "receivedOnId" integer,
    "recolteCoursierId" integer,
    "recolteCSId" integer
);


ALTER TABLE public.recolte OWNER TO dev_pre_prod;

--
-- Name: recolte_facture; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.recolte_facture (
    id integer NOT NULL,
    tracking character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "receivedAt" timestamp without time zone,
    "factureId" integer,
    "createdById" integer,
    "createdOnId" integer,
    "receivedById" integer,
    "receivedOnId" integer
);


ALTER TABLE public.recolte_facture OWNER TO dev_pre_prod;

--
-- Name: recolte_facture_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.recolte_facture_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recolte_facture_id_seq OWNER TO dev_pre_prod;

--
-- Name: recolte_facture_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.recolte_facture_id_seq OWNED BY public.recolte_facture.id;


--
-- Name: recolte_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.recolte_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recolte_id_seq OWNER TO dev_pre_prod;

--
-- Name: recolte_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.recolte_id_seq OWNED BY public.recolte.id;


--
-- Name: rotation; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.rotation (
    id integer NOT NULL,
    "wilayaDepartId" integer NOT NULL,
    "wilayaDestinationId" integer NOT NULL,
    rotation character varying,
    "zoneId" integer NOT NULL
);


ALTER TABLE public.rotation OWNER TO dev_pre_prod;

--
-- Name: rotation_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.rotation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rotation_id_seq OWNER TO dev_pre_prod;

--
-- Name: rotation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.rotation_id_seq OWNED BY public.rotation.id;


--
-- Name: sac; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.sac (
    id integer NOT NULL,
    tracking character varying,
    "typeSac" public.sac_typesac_enum NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "wilayaDestinationId" integer,
    "agenceDestinationId" integer,
    "userId" integer
);


ALTER TABLE public.sac OWNER TO dev_pre_prod;

--
-- Name: sac_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.sac_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sac_id_seq OWNER TO dev_pre_prod;

--
-- Name: sac_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.sac_id_seq OWNED BY public.sac.id;


--
-- Name: sac_shipment; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.sac_shipment (
    id integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "shipmentId" integer,
    "sacId" integer
);


ALTER TABLE public.sac_shipment OWNER TO dev_pre_prod;

--
-- Name: sac_shipment_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.sac_shipment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sac_shipment_id_seq OWNER TO dev_pre_prod;

--
-- Name: sac_shipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.sac_shipment_id_seq OWNED BY public.sac_shipment.id;


--
-- Name: service; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.service (
    id integer NOT NULL,
    nom character varying NOT NULL
);


ALTER TABLE public.service OWNER TO dev_pre_prod;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.service_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_id_seq OWNER TO dev_pre_prod;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: shipment; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.shipment (
    id integer NOT NULL,
    tracking character varying,
    "raisonSociale" character varying,
    nom character varying NOT NULL,
    prenom character varying NOT NULL,
    telephone character varying NOT NULL,
    adresse character varying,
    "numCommande" character varying,
    "designationProduit" character varying NOT NULL,
    "objetRecuperer" character varying,
    "prixVente" integer,
    "prixEstimer" integer,
    poids double precision,
    longueur double precision,
    largeur double precision,
    hauteur double precision,
    echange boolean,
    "livraisonGratuite" boolean,
    "ouvrireColis" boolean,
    "livraisonStopDesck" boolean NOT NULL,
    "livraisonDomicile" boolean NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deleatedAt" timestamp without time zone,
    "lastStatus" public.shipment_laststatus_enum,
    payer boolean DEFAULT false NOT NULL,
    "libererAt" timestamp without time zone,
    "cashOnDelivery" boolean,
    "createdById" integer,
    "serviceId" integer NOT NULL,
    "communeId" integer NOT NULL,
    "expiditeurPublicId" integer,
    "userLastStatusId" integer,
    "recolteId" integer,
    "recolteCsId" integer,
    "libererById" integer,
    "libererOnId" integer,
    "pmtId" integer,
    "pmtCoursierId" integer,
    "shipmentRelationId" integer,
    "factureId" integer,
    "parentShipmentId" integer
);


ALTER TABLE public.shipment OWNER TO dev_pre_prod;

--
-- Name: shipment_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.shipment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipment_id_seq OWNER TO dev_pre_prod;

--
-- Name: shipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.shipment_id_seq OWNED BY public.shipment.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.status (
    libelle public.status_libelle_enum NOT NULL,
    comment character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deleatedAt" timestamp without time zone,
    "userId" integer NOT NULL,
    "shipmentId" integer NOT NULL,
    "userAffectId" integer,
    "createdOnId" integer
);


ALTER TABLE public.status OWNER TO dev_pre_prod;

--
-- Name: wilaya; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.wilaya (
    id integer NOT NULL,
    "codeWilaya" character varying NOT NULL,
    "nomLatin" character varying NOT NULL,
    "nomArabe" character varying NOT NULL,
    "dureeReceptionRecolte" integer,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "deleatedAt" timestamp without time zone,
    "agenceRetourId" integer,
    "caisseRegionalId" integer
);


ALTER TABLE public.wilaya OWNER TO dev_pre_prod;

--
-- Name: wilaya_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.wilaya_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.wilaya_id_seq OWNER TO dev_pre_prod;

--
-- Name: wilaya_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.wilaya_id_seq OWNED BY public.wilaya.id;


--
-- Name: zone; Type: TABLE; Schema: public; Owner: dev_pre_prod
--

CREATE TABLE public.zone (
    id integer NOT NULL,
    "codeZone" character varying NOT NULL
);


ALTER TABLE public.zone OWNER TO dev_pre_prod;

--
-- Name: zone_id_seq; Type: SEQUENCE; Schema: public; Owner: dev_pre_prod
--

CREATE SEQUENCE public.zone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.zone_id_seq OWNER TO dev_pre_prod;

--
-- Name: zone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dev_pre_prod
--

ALTER SEQUENCE public.zone_id_seq OWNED BY public.zone.id;


--
-- Name: Facture id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Facture" ALTER COLUMN id SET DEFAULT nextval('public."Facture_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: agence id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.agence ALTER COLUMN id SET DEFAULT nextval('public.agence_id_seq'::regclass);


--
-- Name: banque id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.banque ALTER COLUMN id SET DEFAULT nextval('public.banque_id_seq'::regclass);


--
-- Name: client id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client ALTER COLUMN id SET DEFAULT nextval('public.client_id_seq'::regclass);


--
-- Name: code_tarif id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarif ALTER COLUMN id SET DEFAULT nextval('public.code_tarif_id_seq'::regclass);


--
-- Name: code_tarifs_zone id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarifs_zone ALTER COLUMN id SET DEFAULT nextval('public.code_tarifs_zone_id_seq'::regclass);


--
-- Name: commune id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.commune ALTER COLUMN id SET DEFAULT nextval('public.commune_id_seq'::regclass);


--
-- Name: coursier id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.coursier ALTER COLUMN id SET DEFAULT nextval('public.coursier_id_seq'::regclass);


--
-- Name: departement id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.departement ALTER COLUMN id SET DEFAULT nextval('public.departement_id_seq'::regclass);


--
-- Name: employe id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe ALTER COLUMN id SET DEFAULT nextval('public.employe_id_seq'::regclass);


--
-- Name: expiditeur_public id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.expiditeur_public ALTER COLUMN id SET DEFAULT nextval('public.expiditeur_public_id_seq'::regclass);


--
-- Name: fonction id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.fonction ALTER COLUMN id SET DEFAULT nextval('public.fonction_id_seq'::regclass);


--
-- Name: pmt id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt ALTER COLUMN id SET DEFAULT nextval('public.pmt_id_seq'::regclass);


--
-- Name: pmt_coursier id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt_coursier ALTER COLUMN id SET DEFAULT nextval('public.pmt_coursier_id_seq'::regclass);


--
-- Name: poid id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.poid ALTER COLUMN id SET DEFAULT nextval('public.poid_id_seq'::regclass);


--
-- Name: recolte id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte ALTER COLUMN id SET DEFAULT nextval('public.recolte_id_seq'::regclass);


--
-- Name: recolte_facture id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture ALTER COLUMN id SET DEFAULT nextval('public.recolte_facture_id_seq'::regclass);


--
-- Name: rotation id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.rotation ALTER COLUMN id SET DEFAULT nextval('public.rotation_id_seq'::regclass);


--
-- Name: sac id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac ALTER COLUMN id SET DEFAULT nextval('public.sac_id_seq'::regclass);


--
-- Name: sac_shipment id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac_shipment ALTER COLUMN id SET DEFAULT nextval('public.sac_shipment_id_seq'::regclass);


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Name: shipment id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment ALTER COLUMN id SET DEFAULT nextval('public.shipment_id_seq'::regclass);


--
-- Name: wilaya id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya ALTER COLUMN id SET DEFAULT nextval('public.wilaya_id_seq'::regclass);


--
-- Name: zone id; Type: DEFAULT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.zone ALTER COLUMN id SET DEFAULT nextval('public.zone_id_seq'::regclass);


--
-- Data for Name: Facture; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3949.dat

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3951.dat

--
-- Data for Name: agence; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3953.dat

--
-- Data for Name: banque; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3955.dat

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3957.dat

--
-- Data for Name: clients_tarif; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3959.dat

--
-- Data for Name: code_tarif; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3960.dat

--
-- Data for Name: code_tarifs_zone; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3962.dat

--
-- Data for Name: commune; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3964.dat

--
-- Data for Name: coursier; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3966.dat

--
-- Data for Name: departement; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3968.dat

--
-- Data for Name: employe; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3970.dat

--
-- Data for Name: expiditeur_public; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3972.dat

--
-- Data for Name: fonction; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3974.dat

--
-- Data for Name: pmt; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3976.dat

--
-- Data for Name: pmt_coursier; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3977.dat

--
-- Data for Name: poid; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3980.dat

--
-- Data for Name: recolte; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3982.dat

--
-- Data for Name: recolte_facture; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3983.dat

--
-- Data for Name: rotation; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3986.dat

--
-- Data for Name: sac; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3988.dat

--
-- Data for Name: sac_shipment; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3990.dat

--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3992.dat

--
-- Data for Name: shipment; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3994.dat

--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3996.dat

--
-- Data for Name: wilaya; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3997.dat

--
-- Data for Name: zone; Type: TABLE DATA; Schema: public; Owner: dev_pre_prod
--

\i $$PATH$$/3999.dat

--
-- Name: Facture_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public."Facture_id_seq"', 2, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public."Users_id_seq"', 21, true);


--
-- Name: agence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.agence_id_seq', 19, true);


--
-- Name: banque_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.banque_id_seq', 16, true);


--
-- Name: client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.client_id_seq', 1, true);


--
-- Name: code_tarif_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.code_tarif_id_seq', 30, true);


--
-- Name: code_tarifs_zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.code_tarifs_zone_id_seq', 1176, true);


--
-- Name: commune_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.commune_id_seq', 1541, true);


--
-- Name: coursier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.coursier_id_seq', 5, true);


--
-- Name: departement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.departement_id_seq', 10, true);


--
-- Name: employe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.employe_id_seq', 14, true);


--
-- Name: expiditeur_public_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.expiditeur_public_id_seq', 70, true);


--
-- Name: fonction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.fonction_id_seq', 3, true);


--
-- Name: pmt_coursier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.pmt_coursier_id_seq', 1, false);


--
-- Name: pmt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.pmt_id_seq', 1, false);


--
-- Name: poid_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.poid_id_seq', 6, true);


--
-- Name: recolte_facture_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.recolte_facture_id_seq', 1, false);


--
-- Name: recolte_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.recolte_id_seq', 1, false);


--
-- Name: rotation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.rotation_id_seq', 2304, true);


--
-- Name: sac_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.sac_id_seq', 1, false);


--
-- Name: sac_shipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.sac_shipment_id_seq', 1, false);


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.service_id_seq', 11, true);


--
-- Name: shipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.shipment_id_seq', 1, false);


--
-- Name: wilaya_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.wilaya_id_seq', 48, true);


--
-- Name: zone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dev_pre_prod
--

SELECT pg_catalog.setval('public.zone_id_seq', 7, true);


--
-- Name: Users PK_16d4f7d636df336db11d87413e3; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_16d4f7d636df336db11d87413e3" PRIMARY KEY (id);


--
-- Name: code_tarif PK_1b4bcc44ce7ab8748c71383e24b; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarif
    ADD CONSTRAINT "PK_1b4bcc44ce7ab8748c71383e24b" PRIMARY KEY (id);


--
-- Name: expiditeur_public PK_1dd23e477158ee414942bc1724d; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.expiditeur_public
    ADD CONSTRAINT "PK_1dd23e477158ee414942bc1724d" PRIMARY KEY (id);


--
-- Name: status PK_56a8a721a53cdec6c03cf2272ae; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT "PK_56a8a721a53cdec6c03cf2272ae" PRIMARY KEY (libelle, "createdAt", "userId", "shipmentId");


--
-- Name: sac_shipment PK_5a137c05f3a68e52abd8ac27e05; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac_shipment
    ADD CONSTRAINT "PK_5a137c05f3a68e52abd8ac27e05" PRIMARY KEY (id, "createdAt");


--
-- Name: pmt PK_5fb86441f3015f050254ca55acc; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "PK_5fb86441f3015f050254ca55acc" PRIMARY KEY (id);


--
-- Name: Facture PK_677ad22d8b2da14dfae9e40976b; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Facture"
    ADD CONSTRAINT "PK_677ad22d8b2da14dfae9e40976b" PRIMARY KEY (id);


--
-- Name: poid PK_6b0634b2fa2e3f412a64c3fce16; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.poid
    ADD CONSTRAINT "PK_6b0634b2fa2e3f412a64c3fce16" PRIMARY KEY (id);


--
-- Name: coursier PK_6b693d375235094d6dffbff71e2; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.coursier
    ADD CONSTRAINT "PK_6b693d375235094d6dffbff71e2" PRIMARY KEY (id);


--
-- Name: employe PK_7113be6659833171e74fa251a18; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe
    ADD CONSTRAINT "PK_7113be6659833171e74fa251a18" PRIMARY KEY (id);


--
-- Name: sac PK_8499d35b4489f96d5df57c0484e; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac
    ADD CONSTRAINT "PK_8499d35b4489f96d5df57c0484e" PRIMARY KEY (id);


--
-- Name: agence PK_84a6b74d35aafb432e0d527f61e; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.agence
    ADD CONSTRAINT "PK_84a6b74d35aafb432e0d527f61e" PRIMARY KEY (id);


--
-- Name: service PK_85a21558c006647cd76fdce044b; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT "PK_85a21558c006647cd76fdce044b" PRIMARY KEY (id);


--
-- Name: banque PK_931b48a7ae358645952d340fdf1; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.banque
    ADD CONSTRAINT "PK_931b48a7ae358645952d340fdf1" PRIMARY KEY (id);


--
-- Name: client PK_96da49381769303a6515a8785c7; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "PK_96da49381769303a6515a8785c7" PRIMARY KEY (id);


--
-- Name: code_tarifs_zone PK_97fefeee4583fdd1bd4d1f0b6c2; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarifs_zone
    ADD CONSTRAINT "PK_97fefeee4583fdd1bd4d1f0b6c2" PRIMARY KEY ("codeTarifId", "zoneId", "poidsId");


--
-- Name: rotation PK_a8757b575d9b694586524b5cffe; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.rotation
    ADD CONSTRAINT "PK_a8757b575d9b694586524b5cffe" PRIMARY KEY (id, "wilayaDepartId", "wilayaDestinationId");


--
-- Name: clients_tarif PK_bb360e7ca8106eb3b3fb70c144d; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.clients_tarif
    ADD CONSTRAINT "PK_bb360e7ca8106eb3b3fb70c144d" PRIMARY KEY ("clientId", "codeTarifId");


--
-- Name: commune PK_bc512eb8412b43c9dc6e2c9e683; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.commune
    ADD CONSTRAINT "PK_bc512eb8412b43c9dc6e2c9e683" PRIMARY KEY (id);


--
-- Name: zone PK_bd3989e5a3c3fb5ed546dfaf832; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.zone
    ADD CONSTRAINT "PK_bd3989e5a3c3fb5ed546dfaf832" PRIMARY KEY (id);


--
-- Name: fonction PK_c51aec05c70e3ce878d5f8d6765; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.fonction
    ADD CONSTRAINT "PK_c51aec05c70e3ce878d5f8d6765" PRIMARY KEY (id);


--
-- Name: recolte PK_c6a3063b99d7ce70981638782bb; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "PK_c6a3063b99d7ce70981638782bb" PRIMARY KEY (id);


--
-- Name: recolte_facture PK_e0cfff9cbf551f2b693677ea7d2; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "PK_e0cfff9cbf551f2b693677ea7d2" PRIMARY KEY (id);


--
-- Name: pmt_coursier PK_e9be479b6781b7b80a6ac3e8da1; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt_coursier
    ADD CONSTRAINT "PK_e9be479b6781b7b80a6ac3e8da1" PRIMARY KEY (id);


--
-- Name: departement PK_f32f7be16ef46566fececc35a34; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.departement
    ADD CONSTRAINT "PK_f32f7be16ef46566fececc35a34" PRIMARY KEY (id);


--
-- Name: shipment PK_f51f635db95c534ca206bf7a0a4; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "PK_f51f635db95c534ca206bf7a0a4" PRIMARY KEY (id);


--
-- Name: wilaya PK_ff2c45578bd6c580cdadbe47b42; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya
    ADD CONSTRAINT "PK_ff2c45578bd6c580cdadbe47b42" PRIMARY KEY (id);


--
-- Name: coursier REL_0623b579abea5e1bbc61903c01; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.coursier
    ADD CONSTRAINT "REL_0623b579abea5e1bbc61903c01" UNIQUE ("userId");


--
-- Name: shipment REL_88090d72edff709f7e8f58bef8; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "REL_88090d72edff709f7e8f58bef8" UNIQUE ("shipmentRelationId");


--
-- Name: client REL_ad3b4bf8dd18a1d467c5c0fc13; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "REL_ad3b4bf8dd18a1d467c5c0fc13" UNIQUE ("userId");


--
-- Name: recolte_facture REL_dfd02a5de59d6f5c32a010b7b2; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "REL_dfd02a5de59d6f5c32a010b7b2" UNIQUE ("factureId");


--
-- Name: employe REL_f24e43fbd53db152a80fc39f02; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe
    ADD CONSTRAINT "REL_f24e43fbd53db152a80fc39f02" UNIQUE ("userId");


--
-- Name: wilaya UQ_10f60702520fb785b99ddaafea8; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya
    ADD CONSTRAINT "UQ_10f60702520fb785b99ddaafea8" UNIQUE ("codeWilaya");


--
-- Name: wilaya UQ_1ee7e3bfa3be8da10a88662d149; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya
    ADD CONSTRAINT "UQ_1ee7e3bfa3be8da10a88662d149" UNIQUE ("nomArabe");


--
-- Name: wilaya UQ_3403e3e6cee17769260966b07a8; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya
    ADD CONSTRAINT "UQ_3403e3e6cee17769260966b07a8" UNIQUE ("nomLatin");


--
-- Name: Users UQ_3c3ab3f49a87e6ddb607f3c4945; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "UQ_3c3ab3f49a87e6ddb607f3c4945" UNIQUE (email);


--
-- Name: sac UQ_3cdf9a47bc145d6116a28ed5f8e; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac
    ADD CONSTRAINT "UQ_3cdf9a47bc145d6116a28ed5f8e" UNIQUE (tracking);


--
-- Name: Facture UQ_8a6546bf0ee79463adaa22fd9b3; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Facture"
    ADD CONSTRAINT "UQ_8a6546bf0ee79463adaa22fd9b3" UNIQUE ("numFacture");


--
-- Name: pmt UQ_92317371af79f69dc539bf8da3d; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "UQ_92317371af79f69dc539bf8da3d" UNIQUE (tracking);


--
-- Name: recolte UQ_980863c92cd1cc5cc898653cc2d; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "UQ_980863c92cd1cc5cc898653cc2d" UNIQUE (tracking);


--
-- Name: recolte_facture UQ_9d177fc844f1ae4941e92f5d33f; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "UQ_9d177fc844f1ae4941e92f5d33f" UNIQUE (tracking);


--
-- Name: pmt_coursier UQ_a9440d575fd5551b9f0a665d19b; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt_coursier
    ADD CONSTRAINT "UQ_a9440d575fd5551b9f0a665d19b" UNIQUE (tracking);


--
-- Name: commune UQ_c6105588398c949589d794fd01d; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.commune
    ADD CONSTRAINT "UQ_c6105588398c949589d794fd01d" UNIQUE ("codePostal");


--
-- Name: shipment UQ_d6e43347ac107b013a3be9604f5; Type: CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "UQ_d6e43347ac107b013a3be9604f5" UNIQUE (tracking);


--
-- Name: IDX_2d18e4f354834e9bdaefc285e0; Type: INDEX; Schema: public; Owner: dev_pre_prod
--

CREATE UNIQUE INDEX "IDX_2d18e4f354834e9bdaefc285e0" ON public.rotation USING btree ("wilayaDepartId", "wilayaDestinationId");


--
-- Name: IDX_7f87e0a82d7cb82ad4974d6d70; Type: INDEX; Schema: public; Owner: dev_pre_prod
--

CREATE UNIQUE INDEX "IDX_7f87e0a82d7cb82ad4974d6d70" ON public.code_tarifs_zone USING btree (id);


--
-- Name: coursier FK_0623b579abea5e1bbc61903c017; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.coursier
    ADD CONSTRAINT "FK_0623b579abea5e1bbc61903c017" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: shipment FK_090591af9b99d4dd2a738599dd2; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_090591af9b99d4dd2a738599dd2" FOREIGN KEY ("expiditeurPublicId") REFERENCES public.expiditeur_public(id);


--
-- Name: shipment FK_0ddccee677c73366dc8e61a340e; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_0ddccee677c73366dc8e61a340e" FOREIGN KEY ("parentShipmentId") REFERENCES public.shipment(id);


--
-- Name: recolte FK_10fe0a69849f8c3f1a146da2d1f; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "FK_10fe0a69849f8c3f1a146da2d1f" FOREIGN KEY ("createdOnId") REFERENCES public.agence(id);


--
-- Name: recolte FK_12a4b7d1d423fa3d8f76583db4e; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "FK_12a4b7d1d423fa3d8f76583db4e" FOREIGN KEY ("receivedById") REFERENCES public."Users"(id);


--
-- Name: pmt FK_1409d0cb29ce2a171653fa453f4; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_1409d0cb29ce2a171653fa453f4" FOREIGN KEY ("validatedOnId") REFERENCES public.agence(id);


--
-- Name: status FK_14ffe3de8a939bf7e664fa9ce5d; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT "FK_14ffe3de8a939bf7e664fa9ce5d" FOREIGN KEY ("shipmentId") REFERENCES public.shipment(id);


--
-- Name: sac FK_1647565e083a912bc2a59340e96; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac
    ADD CONSTRAINT "FK_1647565e083a912bc2a59340e96" FOREIGN KEY ("agenceDestinationId") REFERENCES public.agence(id);


--
-- Name: coursier FK_196b48403d0e9fd9c29b812aae3; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.coursier
    ADD CONSTRAINT "FK_196b48403d0e9fd9c29b812aae3" FOREIGN KEY ("agenceId") REFERENCES public.agence(id);


--
-- Name: pmt FK_1a0b74ad18cc5d629b0b7507dc4; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_1a0b74ad18cc5d629b0b7507dc4" FOREIGN KEY ("wilayaDeparPmtId") REFERENCES public.wilaya(id);


--
-- Name: sac_shipment FK_1af016edd669e7b6130259a0f67; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac_shipment
    ADD CONSTRAINT "FK_1af016edd669e7b6130259a0f67" FOREIGN KEY ("shipmentId") REFERENCES public.shipment(id);


--
-- Name: recolte_facture FK_1e2f690e3da3b323ef853408589; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "FK_1e2f690e3da3b323ef853408589" FOREIGN KEY ("receivedById") REFERENCES public."Users"(id);


--
-- Name: recolte_facture FK_2457cf9d1fe9f8ecebbf9c5c6b9; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "FK_2457cf9d1fe9f8ecebbf9c5c6b9" FOREIGN KEY ("receivedOnId") REFERENCES public.agence(id);


--
-- Name: shipment FK_24ac2217d61a08e561aabb3f39e; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_24ac2217d61a08e561aabb3f39e" FOREIGN KEY ("userLastStatusId") REFERENCES public."Users"(id);


--
-- Name: code_tarif FK_2b8dec28e6a47152d2206922c9c; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarif
    ADD CONSTRAINT "FK_2b8dec28e6a47152d2206922c9c" FOREIGN KEY ("serviceId") REFERENCES public.service(id);


--
-- Name: clients_tarif FK_2c82266ac593f66ddc0f407d449; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.clients_tarif
    ADD CONSTRAINT "FK_2c82266ac593f66ddc0f407d449" FOREIGN KEY ("clientId") REFERENCES public.client(id);


--
-- Name: shipment FK_2ee9ff6c82117cbfdf12617530a; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_2ee9ff6c82117cbfdf12617530a" FOREIGN KEY ("recolteCsId") REFERENCES public.recolte(id);


--
-- Name: pmt_coursier FK_30f4fbf0e642073b924527f8668; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt_coursier
    ADD CONSTRAINT "FK_30f4fbf0e642073b924527f8668" FOREIGN KEY ("coursierId") REFERENCES public.coursier(id);


--
-- Name: recolte FK_322a5f43adb4e9138adfa02a3c9; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "FK_322a5f43adb4e9138adfa02a3c9" FOREIGN KEY ("createdById") REFERENCES public."Users"(id);


--
-- Name: shipment FK_3544e6a46e58c96b5016bf508ce; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_3544e6a46e58c96b5016bf508ce" FOREIGN KEY ("createdById") REFERENCES public."Users"(id);


--
-- Name: pmt FK_358921e73c44a18b137244b82ae; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_358921e73c44a18b137244b82ae" FOREIGN KEY ("validatedById") REFERENCES public."Users"(id);


--
-- Name: wilaya FK_37de5f1c15c64c19819d76bcb8d; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya
    ADD CONSTRAINT "FK_37de5f1c15c64c19819d76bcb8d" FOREIGN KEY ("caisseRegionalId") REFERENCES public.agence(id);


--
-- Name: sac FK_398006854fcfb89fc7371981977; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac
    ADD CONSTRAINT "FK_398006854fcfb89fc7371981977" FOREIGN KEY ("wilayaDestinationId") REFERENCES public.wilaya(id);


--
-- Name: code_tarifs_zone FK_3b9f07b3f29c2aed098ad147ed0; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarifs_zone
    ADD CONSTRAINT "FK_3b9f07b3f29c2aed098ad147ed0" FOREIGN KEY ("poidsId") REFERENCES public.poid(id);


--
-- Name: shipment FK_40de934cccb8a82107961249d4b; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_40de934cccb8a82107961249d4b" FOREIGN KEY ("pmtCoursierId") REFERENCES public.pmt_coursier(id);


--
-- Name: employe FK_4c3455fb7fd93416c19226d6d88; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe
    ADD CONSTRAINT "FK_4c3455fb7fd93416c19226d6d88" FOREIGN KEY ("agenceId") REFERENCES public.agence(id);


--
-- Name: recolte_facture FK_5051d030403622ab0011209602a; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "FK_5051d030403622ab0011209602a" FOREIGN KEY ("createdById") REFERENCES public."Users"(id);


--
-- Name: agence FK_5693616f343bcd1538a0e1a4261; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.agence
    ADD CONSTRAINT "FK_5693616f343bcd1538a0e1a4261" FOREIGN KEY ("communeId") REFERENCES public.commune(id);


--
-- Name: recolte_facture FK_5dc14b32760e1e28d1f2ed228d8; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "FK_5dc14b32760e1e28d1f2ed228d8" FOREIGN KEY ("createdOnId") REFERENCES public.agence(id);


--
-- Name: wilaya FK_6092b6f0aefed0acee30a89fec8; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.wilaya
    ADD CONSTRAINT "FK_6092b6f0aefed0acee30a89fec8" FOREIGN KEY ("agenceRetourId") REFERENCES public.agence(id);


--
-- Name: code_tarifs_zone FK_6353706f347a1f60a0ab9438d66; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarifs_zone
    ADD CONSTRAINT "FK_6353706f347a1f60a0ab9438d66" FOREIGN KEY ("zoneId") REFERENCES public.zone(id);


--
-- Name: pmt_coursier FK_68defad0cbd551e2cdc27eaa8f2; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt_coursier
    ADD CONSTRAINT "FK_68defad0cbd551e2cdc27eaa8f2" FOREIGN KEY ("createdOnId") REFERENCES public.agence(id);


--
-- Name: shipment FK_6a7cda4876453e16b78a914b569; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_6a7cda4876453e16b78a914b569" FOREIGN KEY ("libererOnId") REFERENCES public.agence(id);


--
-- Name: client FK_6aa87774f33c37c6623dcdffb16; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "FK_6aa87774f33c37c6623dcdffb16" FOREIGN KEY ("agenceRetourId") REFERENCES public.agence(id);


--
-- Name: employe FK_6d658aa5b665d4942339cf92075; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe
    ADD CONSTRAINT "FK_6d658aa5b665d4942339cf92075" FOREIGN KEY ("fonctionId") REFERENCES public.fonction(id);


--
-- Name: shipment FK_6e3da15b840bc619d260f46b6c9; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_6e3da15b840bc619d260f46b6c9" FOREIGN KEY ("communeId") REFERENCES public.commune(id);


--
-- Name: pmt FK_6e63bf975c0615e112eaaab5c35; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_6e63bf975c0615e112eaaab5c35" FOREIGN KEY ("createdById") REFERENCES public."Users"(id);


--
-- Name: shipment FK_73da2da4a37b7129ee19e605cf2; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_73da2da4a37b7129ee19e605cf2" FOREIGN KEY ("factureId") REFERENCES public."Facture"(id);


--
-- Name: shipment FK_74ccd4fdcd44067e72119132835; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_74ccd4fdcd44067e72119132835" FOREIGN KEY ("serviceId") REFERENCES public.service(id);


--
-- Name: Facture FK_7a2c1886f3bd2f38337e78f680b; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Facture"
    ADD CONSTRAINT "FK_7a2c1886f3bd2f38337e78f680b" FOREIGN KEY ("clientId") REFERENCES public.client(id);


--
-- Name: sac FK_7c7f4d652421154bc1e728e1456; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac
    ADD CONSTRAINT "FK_7c7f4d652421154bc1e728e1456" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: pmt FK_85dd764db21cdebc8b44ed5e269; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_85dd764db21cdebc8b44ed5e269" FOREIGN KEY ("clientId") REFERENCES public.client(id);


--
-- Name: shipment FK_88090d72edff709f7e8f58bef89; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_88090d72edff709f7e8f58bef89" FOREIGN KEY ("shipmentRelationId") REFERENCES public.shipment(id);


--
-- Name: shipment FK_8aa7eaac5ad8b386ee565fc78b0; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_8aa7eaac5ad8b386ee565fc78b0" FOREIGN KEY ("recolteId") REFERENCES public.recolte(id);


--
-- Name: recolte FK_8f45ce2853b344503783130e731; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "FK_8f45ce2853b344503783130e731" FOREIGN KEY ("recolteCSId") REFERENCES public."Users"(id);


--
-- Name: status FK_8fb0ad8c8976b84bb0bb2515b3e; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT "FK_8fb0ad8c8976b84bb0bb2515b3e" FOREIGN KEY ("createdOnId") REFERENCES public.agence(id);


--
-- Name: client FK_90f6240bddfb5c29a41969283f2; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "FK_90f6240bddfb5c29a41969283f2" FOREIGN KEY ("communeResidenceId") REFERENCES public.commune(id);


--
-- Name: status FK_94cb5dda3cf592da917ec3a2746; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT "FK_94cb5dda3cf592da917ec3a2746" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: recolte FK_a4944305ccfbc9548d66a43fb2b; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "FK_a4944305ccfbc9548d66a43fb2b" FOREIGN KEY ("receivedOnId") REFERENCES public.agence(id);


--
-- Name: Facture FK_a6dbed7bd05780be8f52a529f25; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Facture"
    ADD CONSTRAINT "FK_a6dbed7bd05780be8f52a529f25" FOREIGN KEY ("createdOnId") REFERENCES public.agence(id);


--
-- Name: client FK_a9978f62f2996047a237bc4cfe3; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "FK_a9978f62f2996047a237bc4cfe3" FOREIGN KEY ("caisseAgenceId") REFERENCES public.agence(id);


--
-- Name: client FK_ad3b4bf8dd18a1d467c5c0fc13a; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "FK_ad3b4bf8dd18a1d467c5c0fc13a" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: rotation FK_b1b22e2f6f8a5a1d20ca754e1a5; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.rotation
    ADD CONSTRAINT "FK_b1b22e2f6f8a5a1d20ca754e1a5" FOREIGN KEY ("wilayaDepartId") REFERENCES public.wilaya(id);


--
-- Name: shipment FK_b1f7f8489a761276bef6246991f; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_b1f7f8489a761276bef6246991f" FOREIGN KEY ("pmtId") REFERENCES public.pmt(id);


--
-- Name: pmt FK_b9bb94aabb99349953501bd00ea; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_b9bb94aabb99349953501bd00ea" FOREIGN KEY ("confirmedById") REFERENCES public."Users"(id);


--
-- Name: recolte FK_be0a0f22f733656bf133d9b879e; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte
    ADD CONSTRAINT "FK_be0a0f22f733656bf133d9b879e" FOREIGN KEY ("recolteCoursierId") REFERENCES public."Users"(id);


--
-- Name: pmt FK_be5b717a216db0bf69f00be49ec; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt
    ADD CONSTRAINT "FK_be5b717a216db0bf69f00be49ec" FOREIGN KEY ("createdOnId") REFERENCES public.agence(id);


--
-- Name: clients_tarif FK_bfc28d3cf70defcd40635e7ac21; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.clients_tarif
    ADD CONSTRAINT "FK_bfc28d3cf70defcd40635e7ac21" FOREIGN KEY ("codeTarifId") REFERENCES public.code_tarif(id);


--
-- Name: status FK_c82ba6c32c0b50f5e331527e271; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT "FK_c82ba6c32c0b50f5e331527e271" FOREIGN KEY ("userAffectId") REFERENCES public."Users"(id);


--
-- Name: rotation FK_ceef0ea6bc0bb5543d72313457b; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.rotation
    ADD CONSTRAINT "FK_ceef0ea6bc0bb5543d72313457b" FOREIGN KEY ("zoneId") REFERENCES public.zone(id);


--
-- Name: shipment FK_d155bf5974de8fb98a156a8a2fc; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT "FK_d155bf5974de8fb98a156a8a2fc" FOREIGN KEY ("libererById") REFERENCES public."Users"(id);


--
-- Name: rotation FK_d37b5ffee30c36dcf38b0205c79; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.rotation
    ADD CONSTRAINT "FK_d37b5ffee30c36dcf38b0205c79" FOREIGN KEY ("wilayaDestinationId") REFERENCES public.wilaya(id);


--
-- Name: employe FK_df44084a659ca234f8b316c4e8b; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe
    ADD CONSTRAINT "FK_df44084a659ca234f8b316c4e8b" FOREIGN KEY ("banqueId") REFERENCES public.banque(id);


--
-- Name: recolte_facture FK_dfd02a5de59d6f5c32a010b7b20; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.recolte_facture
    ADD CONSTRAINT "FK_dfd02a5de59d6f5c32a010b7b20" FOREIGN KEY ("factureId") REFERENCES public."Facture"(id);


--
-- Name: sac_shipment FK_e6e23c0a09ec52df7788da825d9; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.sac_shipment
    ADD CONSTRAINT "FK_e6e23c0a09ec52df7788da825d9" FOREIGN KEY ("sacId") REFERENCES public.sac(id);


--
-- Name: code_tarifs_zone FK_ed5b4407e8117a1f54fde4f008b; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.code_tarifs_zone
    ADD CONSTRAINT "FK_ed5b4407e8117a1f54fde4f008b" FOREIGN KEY ("codeTarifId") REFERENCES public.code_tarif(id);


--
-- Name: commune FK_eeec3f277fdce4252e0ced3d621; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.commune
    ADD CONSTRAINT "FK_eeec3f277fdce4252e0ced3d621" FOREIGN KEY ("wilayaId") REFERENCES public.wilaya(id);


--
-- Name: pmt_coursier FK_f1ed36a75b679f95e57b8fae917; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.pmt_coursier
    ADD CONSTRAINT "FK_f1ed36a75b679f95e57b8fae917" FOREIGN KEY ("createdById") REFERENCES public."Users"(id);


--
-- Name: employe FK_f24e43fbd53db152a80fc39f025; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.employe
    ADD CONSTRAINT "FK_f24e43fbd53db152a80fc39f025" FOREIGN KEY ("userId") REFERENCES public."Users"(id);


--
-- Name: client FK_f7c78298cec2cd7066866e599e8; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT "FK_f7c78298cec2cd7066866e599e8" FOREIGN KEY ("communeDepartId") REFERENCES public.commune(id);


--
-- Name: Facture FK_f8cb6d41c96e31d122a22031e57; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public."Facture"
    ADD CONSTRAINT "FK_f8cb6d41c96e31d122a22031e57" FOREIGN KEY ("createdById") REFERENCES public."Users"(id);


--
-- Name: fonction FK_fdd5c8466630fabf3185b7c6ccd; Type: FK CONSTRAINT; Schema: public; Owner: dev_pre_prod
--

ALTER TABLE ONLY public.fonction
    ADD CONSTRAINT "FK_fdd5c8466630fabf3185b7c6ccd" FOREIGN KEY ("departementId") REFERENCES public.departement(id);


--
-- PostgreSQL database dump complete
--

